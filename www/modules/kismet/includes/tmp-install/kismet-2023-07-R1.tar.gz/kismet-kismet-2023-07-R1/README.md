https://www.kismetwireless.net

The Kismet docs can be most easily found and read at [the Kismet website](https://www.kismetwireless.net/docs/readme/intro/kismet/)


The docs repository is at:

```bash
$ git clone https://www.kismetwireless.net/git/kismet-docs.git
```

and mirrored on Github at:

```bash
$ git clone https://www.github.com/kismetwireless/kismet-docs
```

